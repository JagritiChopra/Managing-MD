// services/api.ts
import * as SecureStore from "expo-secure-store";

// BUG FIX #1: Was hardcoded to a local IP (http://10.161.214.23:5000/api).
// Production URL is now the active default, pulled from the .env convention.
// Set EXPO_PUBLIC_API_URL in your .env to override.
// const API_URL =
//   process.env.EXPO_PUBLIC_API_URL ??
//   "https://managing-maladaptive-daydreaming.onrender.com/api";

const API_URL = "http://10.161.214.108:5000/api";

export async function apiRequest(
  endpoint: string,
  method = "GET",
  body?: unknown,
  requiresAuth = false
) {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };

  // BUG FIX #2: Authenticated endpoints (e.g. /auth/me) never had the token
  // injected into the Authorization header — they would always 401.
  if (requiresAuth) {
    const token = await SecureStore.getItemAsync("auth_token");
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }
  }

  const res = await fetch(`${API_URL}${endpoint}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.message || "Something went wrong");
  }

  return data;
}

// // services/api.ts
// const API_URL = "http://10.161.214.23:5000/api";

// //const API_URL = "https://managing-maladaptive-daydreaming.onrender.com/api";

// export async function apiRequest(endpoint: string, method = "GET", body?: any) {
//   const res = await fetch(`${API_URL}${endpoint}`, {
//     method,
//     headers: {
//       "Content-Type": "application/json",
//     },
//     body: body ? JSON.stringify(body) : undefined,
//   });

//   const data = await res.json();

//   if (!res.ok) {
//     throw new Error(data.message || "Something went wrong");
//   }

//   return data;
// }