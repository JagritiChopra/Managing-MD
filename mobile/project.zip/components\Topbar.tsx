import React from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type TopBarProps = {
  title: string;
  onBackPress?: () => void;
  rightIcon?: keyof typeof Ionicons.glyphMap;
  onRightPress?: () => void;
};

const TopBar: React.FC<TopBarProps> = ({
  title,
  onBackPress,
  rightIcon,
  onRightPress,
}) => {
  const insets = useSafeAreaInsets();

  return (
    <View
      className="bg-surface-light border-b border-white/10"
      style={{ paddingTop: insets.top - 28 }} // reduce top padding here, adjust -8 to taste
    >
      <View
        style={{ height: 56 }}
        className="flex-row items-center justify-between px-4"
      >
        {/* LEFT */}
        <View style={{ width: 40 }} className="items-start">
          {onBackPress && (
            <TouchableOpacity onPress={onBackPress} hitSlop={8}>
              <Ionicons name="arrow-back" size={24} color="#FFFFFF" />
            </TouchableOpacity>
          )}
        </View>

        {/* CENTER */}
        <View className="flex-1 items-center">
          <Text className="text-white text-lg font-semibold tracking-wide">
            {title}
          </Text>
        </View>

        {/* RIGHT */}
        <View style={{ width: 40 }} className="items-end">
          {rightIcon ? (
            <TouchableOpacity onPress={onRightPress} hitSlop={8}>
              <Ionicons name={rightIcon} size={24} color="#FFFFFF" />
            </TouchableOpacity>
          ) : (
            <View />
          )}
        </View>
      </View>
    </View>
  );
};

export default TopBar;